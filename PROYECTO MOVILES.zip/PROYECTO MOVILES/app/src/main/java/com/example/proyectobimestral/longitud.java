package com.example.proyectobimestral;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class longitud extends Fragment {

    EditText editValor;
    Spinner Spinner;
    Button botonEjecutar;
    TextView textResultado;
    ArrayAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        editValor = getActivity().findViewById(R.id.editValor);
        Spinner = getActivity().findViewById(R.id.Spinner);
        botonEjecutar = getActivity().findViewById(R.id.botonEjecutar);
        textResultado = getActivity().findViewById(R.id.textResultado);
        adapter = ArrayAdapter.createFromResource(getActivity(), R.array.a_longitud, android.R.layout.simple_spinner_dropdown_item);
        Spinner.setAdapter(adapter);
        Spinner.setOnItemSelectedListener(new SpinnerActivity());

        botonEjecutar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            }
        });

        return inflater.inflate(R.layout.fragment_longitud, container, false);


    }

    private class SpinnerActivity implements AdapterView.OnItemSelectedListener {

        @Override
        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
            String medida = adapterView.getItemAtPosition(i).toString();
            Toast.makeText(getActivity(), medida, Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onNothingSelected(AdapterView<?> adapterView) {

        }
    }
}