package com.example.proyectobimestral;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;

public class MainActivity extends AppCompatActivity {

    // Llamamos a los botones
    Button bLong, bMasa, bVol;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Buscamos a los botones en el front y los llamamos al back.
        bLong = findViewById(R.id.BotonLongitud);
        bMasa = findViewById(R.id.BotonMasa);
        bVol = findViewById(R.id.BotonVolumen);

        // Los listener de cada botón para poder abrir los fragments.
        bLong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirFragLong();
            }
        });
        bMasa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirFragMasa();
            }
        });
        bVol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirFragVol();
            }
        });

        getSupportFragmentManager().addOnBackStackChangedListener(new FragmentManager.OnBackStackChangedListener() {
            @Override
            public void onBackStackChanged() {
                if (getSupportFragmentManager().getBackStackEntryCount() == 0) {
                    mostrarBotones(true);
                } else {
                    mostrarBotones(false);
                }
            }
        });

    } // Reminder: este pertenece al create.



    private void abrirFragLong() {

    }
    private void abrirFragMasa() {

    }
    private void abrirFragVol() {
    }


    private void mostrarBotones(boolean mostrar) {
        int visibilidad = mostrar ? View.VISIBLE : View.GONE;
        bLong.setVisibility(visibilidad);
        bMasa.setVisibility(visibilidad);
        bVol.setVisibility(visibilidad);
    }



} // Reminder:  este es el último.