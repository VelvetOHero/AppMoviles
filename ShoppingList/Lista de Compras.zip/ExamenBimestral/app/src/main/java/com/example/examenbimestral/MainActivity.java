package com.example.examenbimestral;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Detergente, Jabon Liquido, Suavizante, Jabon en barra, Cloro, Fibra
    CheckBox cbD, cbJL, cbS, cbJB, cbC, cbF;
    EditText etD, etJL, etS, etJB, etC, etF;
    TextView tvTotal;
    Button bCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Hacemos el puente entre front y back-end
        // Checkbox
        cbD = findViewById(R.id.cbD);
        cbJL = findViewById(R.id.cbJL);
        cbS = findViewById(R.id.cbS);
        cbJB = findViewById(R.id.cbJB);
        cbC = findViewById(R.id.cbC);
        cbF = findViewById(R.id.cbF);

        //Edit Text
        etD = findViewById(R.id.etD);
        etJL = findViewById(R.id.etJL);
        etS = findViewById(R.id.etS);
        etJB = findViewById(R.id.etJB);
        etC = findViewById(R.id.etC);
        etF = findViewById(R.id.etF);

        // TextView
        tvTotal = findViewById(R.id.tvTotal);

        // Button
        bCalcular = findViewById(R.id.bCalcular);

        bCalcular.setOnClickListener(v -> {

            //Variables booleanas
            boolean cbd, cbjl, cbs, cbjb, cbc, cbf;
            cbd = cbD.isChecked();
            cbjl = cbJL.isChecked();
            cbs = cbS.isChecked();
            cbjb = cbJB.isChecked();
            cbc = cbC.isChecked();
            cbf = cbF.isChecked();

            //Variables locales para los ET
            float etd, etjl, ets, etjb, etc, etf;
            etd = 0;
            etjl = 0;
            ets = 0;
            etjb = 0;
            etc = 0;
            etf = 0;


            // Variables locales.
            String tv;

            // Revisamos si las CBs están con check o no
            if (cbd == true)
            {
                etd = Float.parseFloat(etD.getText().toString());
                etd = etd*130;

            } if (cbjl == true)
            {
                etjl = Float.parseFloat(etJL.getText().toString());
                etjl = etjl*230;
            } if (cbs == true)
            {
                ets = Float.parseFloat(etS.getText().toString());
                ets = ets*80;
            } if (cbjb == true)
            {
                etjb = Float.parseFloat(etJB.getText().toString());
                etjb = etjb*40;
            } if (cbc == true)
            {
                etc = Float.parseFloat(etC.getText().toString());
                etc = etc*40;
            } if (cbf == true)
            {
                etf = Float.parseFloat(etF.getText().toString());
                etf = etf*40;
            }

            float resultado = etd+etjl+ets+etjb+etc+etf;
            tv = String.valueOf(resultado);
            tvTotal.setText(tv);

        });



    } // fin OnCreate
} // Fin MainActivity