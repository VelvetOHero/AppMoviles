package com.example.practica4;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button boton;
    TextView test;
    TextView salida;
    EditText enHora;
    EditText enMin;
    EditText salHora;
    EditText salMin;

    double tiempoE;
    double tiempoS;

    int tiempo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        boton = findViewById(R.id.boton1);
        test = findViewById(R.id.TiempoEstimado);
        salida = findViewById(R.id.MontoFinal);
        enHora = findViewById(R.id.entradaHoras);
        enMin = findViewById(R.id.entradaMinutos);
        salHora = findViewById(R.id.salidaHoras);
        salMin = findViewById(R.id.salidaMinutos);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enhora = enHora.getText().toString();
                String enmin = enMin.getText().toString();
                String salhora = salHora.getText().toString();
                String salmin = salMin.getText().toString();

                if (!enhora.isEmpty() && !enmin.isEmpty()) {
                    int horas = Integer.parseInt(enhora);
                    int minutos = Integer.parseInt(enmin);
                    tiempoE = horas + (minutos / 60.0);
                }

                if (!salhora.isEmpty() && !salmin.isEmpty()) {
                    int horas = Integer.parseInt(salhora);
                    int minutos = Integer.parseInt(salmin);
                    tiempoS = horas + (minutos / 60.0);
                }
            }
        }
    }
}
