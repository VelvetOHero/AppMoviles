package com.example.practica3;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Declaración de variables para importar del front
    Spinner spinnerDesde;
    Spinner spinnerHasta;
    TextView resultado;
    ArrayAdapter adapter;
    Button boton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Importar variables
        spinnerDesde = findViewById(R.id.spinnerFrom);
        spinnerHasta = findViewById(R.id.spinnerTo);
        resultado = findViewById(R.id.textoMonto);
        adapter = ArrayAdapter.createFromResource(this,R.array.Monedas, android.R.layout.simple_spinner_dropdown_item);
        spinnerDesde.setAdapter(adapter);
        spinnerHasta.setAdapter(adapter);
        spinnerDesde.setOnItemSelectedListener(new SpinnerListener());
        spinnerHasta.setOnItemSelectedListener(new SpinnerListener());
        boton = findViewById(R.id.button);

        boton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                
            }
        });
            }
        }



    
     class SpinnerListener implements android.widget.AdapterView.OnItemSelectedListener {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            String moneda = parent.getItemAtPosition(position).toString();
            //Toast.makeText(MainActivity.this, moneda, Toast.LENGTH_SHORT).show();
            
        }
        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }