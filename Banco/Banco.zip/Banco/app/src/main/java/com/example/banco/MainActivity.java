package com.example.banco;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Declaramos variables globales.
    EditText origen, destino, monto, nombre, balance;
    Button transfer, agregar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        origen = findViewById(R.id.CuentaOrigen);
        destino = findViewById(R.id.CuentaDestino);
        monto = findViewById(R.id.Monto);
        nombre = findViewById(R.id.Nombre);
        balance = findViewById(R.id.Balance);
        transfer = findViewById(R.id.BotonTransfer);
        agregar = findViewById(R.id.BotonAgregar);

    }
}