package com.example.tuleperaconlabanana;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ArrayAdapter;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.tuleperaconlabanana.databinding.ActivityMainBinding;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    ArrayList<String> lista;
    ArrayAdapter<String> adapter;
    Handler handler = new Handler();
    ProgressDialog progressDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        inicializaLista();
    }

    private void inicializaLista() {
        lista = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,lista);
        binding.lista.setAdapter(adapter);
        binding.boton.setOnClickListener(new View.OnClickListener() {
            @Override
                    public void onClick(View v) {
                String cantidadStr = binding.cantidad.getText().toString();
                double cantidad = 1.0;
                if (!cantidadStr.isEmpty())
                {
                    cantidad = Double.parseDouble(cantidadStr);
                }
                new fetchData(cantidad).start();
            }
        });
    }

    private class fetchData extends Thread {

        String data ="";
        double cantidad;
        public fetchData(double cantidad) {
            this.cantidad = cantidad;
        }

        @Override
        public void run() {
            super.run();

            // Handler
            handler.post(new Runnable() {
                @Override
                public void run() {
                    progressDialog = new ProgressDialog(MainActivity.this);
                    progressDialog.setMessage("Obteniendo datos");
                    progressDialog.setCancelable(false);
                    progressDialog.show();
                }
            });

            try {
                URL url = new URL("https://api.npoint.io/cac8617e52454e60135b");
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line=bufferedReader.readLine()) != null)
                {
                    data = data + line;
                }

                if (!data.isEmpty())
                {
                    lista.clear();
                    JSONObject jsonObject = new JSONObject(data);
                    JSONObject rates = jsonObject.getJSONObject("rates");
                    String base = jsonObject.getString("base");
                    double aud1 = rates.getDouble("AUD")*cantidad;
                    double cad1 = rates.getDouble("CAD")*cantidad;
                    String audString = String.format("AUD x %.2f = %.2f", cantidad,aud1);
                    String cadString = String.format("CAD x %.2f = %.2f", cantidad,cad1);
                    lista.add(audString);
                    lista.add(cadString);
                }

            } catch (MalformedURLException e){
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }

            handler.post(new Runnable() {
                @Override
                public void run() {
                    if (progressDialog.isShowing())
                    {
                    progressDialog.dismiss();
                    adapter.notifyDataSetChanged();
                    }
                }
            });
        }
    }
}
